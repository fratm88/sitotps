<?php
// Parametri di connessione al database
$servername = "localhost";
$username = "5id15";
$password = "4f68";
$dbname = "5id15";

// Crea la connessione
$conn = new mysqli($servername, $username, $password, $dbname);

// Controlla la connessione
if ($conn->connect_error) {
    die("Connessione al database fallita: " . $conn->connect_error);
}
// Funzione per pulire e filtrare l'input
function clean_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Funzione per l'hashing della password con SHA-256 
function hash_password($password) {
    return hash('sha256', $password);
}

/*
// Funzione per generare un salt casuale
function generate_salt($length = 16) {
    return bin2hex(random_bytes($length));
}

// Funzione per l'hashing della password con PBKDF2 (sha256, salt e ripetuto un po' di volte)
function hash_password($password, $salt) {
    $iterations = 1000; // Numero di iterazioni
    $hash_length = 32; // Lunghezza dell'output hash in byte
    $algo = 'sha256'; // Algoritmo di hashing
    return hash_pbkdf2($algo, $password, $salt, $iterations, $hash_length);
}*/
?>
