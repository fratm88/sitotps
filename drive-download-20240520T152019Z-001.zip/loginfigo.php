<!DOCTYPE html>
<html>
<head>
    <title>Login Guida Turistica Padova</title>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <link rel='stylesheet' href='loginfigo.css'>
</head>
<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form method="post" action="loginfigo.php">
                    <h2>Login</h2>
                    <div class="inputbox"> <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="password"> <label>Password</label>
                    </div>
                    <button>Invio</button>
                </form>
            </div>
        </div>
    </section>
     <?php
        ini_set('display_errors', 1);
        ini_set('log_errors', 1);
        error_reporting(E_ALL);
        // Includi le funzioni di utilità
        include('funzioni.php');


        // Variabili per memorizzare i messaggi di errore
        $errors = array();


        // Controlla se il modulo di login è stato inviato
        if ($_POST) {
            // Filtra e valida l'input
            $password = clean_input($_POST["password"]);

            echo $password;
            // Verifica che i campi non siano vuoti
            if (empty($password)) {
                $errors[] = "Inserisci una password";
            }


            // Se non ci sono errori di input, procedi con il login
            if (empty($errors)) {
                // Recupera l'hash della password memorizzata nel database
                $query = "SELECT Password FROM BIGLIETTO WHERE Password='$password'";
                $result = $conn->query($query);
                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    $stored_password_hash = $row['Password'];


                    // Verifica se la password inserita corrisponde all'hash memorizzato nel database
                    if ($password == $stored_password_hash) {
                        // Password corretta, login avvenuto con successo
                        echo"password ok";
                            header('Location: homepage.html');
                            //exit;
                        } else {
                            // Password errata
                            $errors[] = "Password errata";
                        }
                    } else {
                        // Nome utente non trovato nel database
                        $errors[] = "Password non valida";
                    }
                }


                // Se ci sono errori, mostra i messaggi di errore
                if (!empty($errors)) {
                    foreach ($errors as $error) {
                        echo "<script type='text/javascript'>alert('$error');</script>";
                    }
                }
            }
        ?>
    


   
</body>
</html>
